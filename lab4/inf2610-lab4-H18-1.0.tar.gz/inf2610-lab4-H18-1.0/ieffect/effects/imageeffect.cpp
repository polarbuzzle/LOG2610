#include "imageeffect.h"

ImageEffect::ImageEffect()
{
}
